package com.rentalproject.dto;

import lombok.Data;

@Data
public class PrivateQnaAttachDto {

	private int attachNo;
	private	int qnaNo;
	private String attachFileName;
	private String savedFileName;

	
}
