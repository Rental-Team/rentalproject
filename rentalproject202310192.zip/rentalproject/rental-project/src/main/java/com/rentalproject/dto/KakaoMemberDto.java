package com.rentalproject.dto;

import lombok.Data;

@Data
public class KakaoMemberDto {

	private String kakaoEmail;
	private String kakaoNickname;
}
