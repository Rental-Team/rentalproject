package com.rentalproject.dto;

import lombok.Data;

@Data
public class PrivateQnaAnswerDto {

private int	qnaNo;
private String answerContent;
private String adminId;
private boolean deleted;

	
	
}
