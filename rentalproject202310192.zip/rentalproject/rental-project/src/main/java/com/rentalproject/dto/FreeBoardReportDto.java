package com.rentalproject.dto;

import lombok.Data;

@Data
public class FreeBoardReportDto {

	private int freeBoardReportNo;
	private int memberNo;
	private String memberId;
	private int freeBoardNo; 
	
}
